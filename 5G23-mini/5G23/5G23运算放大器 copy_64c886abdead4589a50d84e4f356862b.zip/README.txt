<p>5G23是上世纪70年代，上海元件五厂研制的一种通用运算放大器。</p>
<p>&nbsp;</p>
<p>其相比于F001只多了两颗等效晶体管，但是性能均衡型大大提高，输入范围更大，输出阻抗更低，对电源要求更宽松，且不需要连接地线。</p>
<p>在电路结构上来说，F004可能是我国自主研制的第一种集成运放（F001-F003均为仿制外国型号）。</p>
<p>&nbsp;</p>
<p>该项目使用分立元件构建该运算范大器，实测可用。</p>
<p>制作完成后使用面包板进行测试，搭建了一个含有施密特触发器的振荡器，输出接LED，可以看到LED闪烁。</p>
<p>&nbsp;</p>
<p><img src="//image.lceda.cn/pullimage/5Z6XBmetKfRY6g590sio91v2TgzZWZlVQ8eupdKZ.jpeg" alt="" width="900" height="675" /><img src="//image.lceda.cn/pullimage/02umh8B0PTiqYykMJNKsWLARzyiateaAqkFg2h2v.jpeg" alt="" width="900" height="675" /><img src="//image.lceda.cn/pullimage/eynaKve1T1EU4HgGFGGoIjOAYBbBivgkEV8AURAy.jpeg" alt="" width="900" height="675" /></p>
<p>&nbsp;</p>
<p>测试电路：</p>
<p><img src="//image.lceda.cn/pullimage/a8g7lu4WUZVdy1TQ3tD5Smg2UXY4NDY6EhiOEQUu.png" alt="" width="762" height="523" /></p>
<p>&nbsp;</p>
<p>&nbsp;</p>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。